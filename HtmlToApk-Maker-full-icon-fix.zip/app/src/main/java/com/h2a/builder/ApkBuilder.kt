package com.h2a.builder

import android.content.Context
import android.net.Uri
import com.android.apksig.ApkSigner
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Template APK (runner) ko copy karta hai, uska package name + app name patch karta hai,
 * icon badalta hai, user ki HTML/ZIP + config.json daalta hai, phir sign karta hai.
 */
object ApkBuilder {
    private const val PKG_PH = "com.h2a.app00000000"
    private const val LABEL_PH = "APPLABELPLACEHOLDER0123456789X"

    fun build(ctx: Context, kind: String, src: Uri, cfg: JSONObject, icon: ByteArray, out: File, say: (String) -> Unit) {
        val label = cleanLabel(cfg.optString("name", "App"))
        val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        val newPkg = "com.h2a.app" + (1..8).map { chars.random() }.joinToString("")
        val unsigned = File(ctx.cacheDir, "unsigned.apk")
        unsigned.delete(); out.delete()
        val seen = HashSet<String>()
        var iconResourcesReplaced = 0

        say("Template tayar ho raha hai...")
        ZipOutputStream(FileOutputStream(unsigned)).use { zos ->
            fun put(name: String, data: ByteArray) {
                if (!seen.add(name)) return
                zos.putNextEntry(ZipEntry(name)); zos.write(data); zos.closeEntry()
            }
            ZipInputStream(ctx.assets.open("template.apk")).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val n = e.name
                    if (!e.isDirectory && !n.startsWith("META-INF/")) {
                        val bytes = zin.readBytes()
                        val data = when {
                            n == "AndroidManifest.xml" -> patchLabel(patchPkg(bytes, newPkg), label)
                            n == "resources.arsc" -> patchPkg(bytes, newPkg)
                            // Support both classic launcher icons and adaptive-icon foregrounds.
                            // Some Android builds package launcher images as WebP rather than PNG.
                            n.startsWith("res/") && isLauncherImage(n) -> {
                                iconResourcesReplaced++
                                encodeForEntry(icon, n)
                            }
                            else -> bytes
                        }
                        put(n, data)
                    }
                    zin.closeEntry(); e = zin.nextEntry
                }
            }
            if (iconResourcesReplaced == 0) {
                throw Exception("Template mein launcher icon resource nahi mili. Runner template dobara build karein.")
            }
            say("Launcher icon resources update: $iconResourcesReplaced")
            put("assets/config.json", cfg.toString().toByteArray())

            say("Aap ki file andar daali ja rahi hai...")
            if (kind == "html") {
                put("assets/www/index.html", ctx.contentResolver.openInputStream(src)!!.use { it.readBytes() })
            } else {
                val names = ArrayList<String>()
                ZipInputStream(ctx.contentResolver.openInputStream(src)!!).use { z ->
                    var e = z.nextEntry
                    while (e != null) { names.add(e.name); e = z.nextEntry }
                }
                val idx = names.filter {
                    !it.startsWith("__MACOSX") && (it == "index.html" || it.endsWith("/index.html"))
                }.minByOrNull { it.length } ?: throw Exception("ZIP ke andar index.html nahi mili")
                val prefix = idx.removeSuffix("index.html")
                ZipInputStream(ctx.contentResolver.openInputStream(src)!!).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val n = e.name.replace('\\', '/')
                        if (!e.isDirectory && n.startsWith(prefix) && !n.startsWith("__MACOSX")) {
                            val rel = n.removePrefix(prefix)
                            if (!rel.contains("..")) put("assets/www/$rel", z.readBytes())
                        }
                        z.closeEntry(); e = z.nextEntry
                    }
                }
            }
        }

        say("APK sign ho rahi hai...")
        val pass = "android".toCharArray()
        val ks = KeyStore.getInstance("PKCS12")
        ctx.assets.open("sign.p12").use { ks.load(it, pass) }
        val alias = ks.aliases().nextElement()
        val key = ks.getKey(alias, pass) as PrivateKey
        val cert = ks.getCertificate(alias) as X509Certificate
        val signer = ApkSigner.SignerConfig.Builder("h2a", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(signer))
            .setInputApk(unsigned)
            .setOutputApk(out)
            .setMinSdkVersion(24)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(false)
            .build()
            .sign()
        unsigned.delete()
    }


    private fun isLauncherImage(name: String): Boolean {
        val lower = name.lowercase()
        if (!lower.startsWith("res/")) return false
        val imageFile = lower.endsWith(".png") || lower.endsWith(".webp")
        if (!imageFile) return false
        val base = lower.substringAfterLast('/').substringBeforeLast('.')
        // Replace legacy, round, and adaptive foreground/monochrome launcher image assets.
        return base == "ic_launcher" || base == "ic_launcher_round" ||
            base == "ic_launcher_foreground" || base == "ic_launcher_monochrome"
    }

    private fun encodeForEntry(png: ByteArray, name: String): ByteArray {
        val bitmap = android.graphics.BitmapFactory.decodeByteArray(png, 0, png.size)
            ?: throw Exception("Selected icon image decode nahi ho saki")
        val lower = name.lowercase()
        val size = when {
            lower.contains("mipmap-mdpi") -> 48
            lower.contains("mipmap-hdpi") -> 72
            lower.contains("mipmap-xhdpi") -> 96
            lower.contains("mipmap-xxhdpi") -> 144
            lower.contains("mipmap-xxxhdpi") -> 192
            else -> 192
        }
        val scaled = if (bitmap.width == size && bitmap.height == size) bitmap
            else android.graphics.Bitmap.createScaledBitmap(bitmap, size, size, true)
        val out = java.io.ByteArrayOutputStream()
        if (lower.endsWith(".webp")) {
            @Suppress("DEPRECATION")
            scaled.compress(android.graphics.Bitmap.CompressFormat.WEBP, 100, out)
        } else {
            scaled.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
        }
        if (scaled !== bitmap) scaled.recycle()
        bitmap.recycle()
        return out.toByteArray()
    }

    private fun cleanLabel(s: String): String {
        var l = s.replace(Regex("[\\u0000-\\u001f]"), "").trim().take(30)
        while (l.toByteArray(Charsets.UTF_8).size > 30) l = l.dropLast(1)
        return l.ifBlank { "App" }
    }

    private fun patchPkg(d: ByteArray, pkg: String): ByteArray {
        var r = replaceAll(d, PKG_PH.toByteArray(Charsets.UTF_16LE), pkg.toByteArray(Charsets.UTF_16LE))
        r = replaceAll(r, PKG_PH.toByteArray(Charsets.UTF_8), pkg.toByteArray(Charsets.UTF_8))
        return r
    }

    // String pool mein length prefix + chars + null likh kar baqi hissa zero kar deta hai (chunk size same rehta hai)
    private fun patchLabel(d: ByteArray, label: String): ByteArray {
        val n = LABEL_PH.length
        val old16 = byteArrayOf(n.toByte(), 0) + LABEL_PH.toByteArray(Charsets.UTF_16LE) + byteArrayOf(0, 0)
        val new16 = (byteArrayOf(label.length.toByte(), 0) + label.toByteArray(Charsets.UTF_16LE) + byteArrayOf(0, 0))
            .copyOf(old16.size)
        var r = replaceAll(d, old16, new16)
        val old8 = byteArrayOf(n.toByte(), n.toByte()) + LABEL_PH.toByteArray(Charsets.UTF_8) + byteArrayOf(0)
        val lb = label.toByteArray(Charsets.UTF_8)
        val new8 = (byteArrayOf(label.length.toByte(), lb.size.toByte()) + lb + byteArrayOf(0)).copyOf(old8.size)
        r = replaceAll(r, old8, new8)
        return r
    }

    private fun replaceAll(d: ByteArray, a: ByteArray, b: ByteArray): ByteArray {
        require(a.size == b.size)
        val o = d.copyOf()
        var i = 0
        while (i <= o.size - a.size) {
            var m = true
            for (j in a.indices) if (o[i + j] != a[j]) { m = false; break }
            if (m) { System.arraycopy(b, 0, o, i, b.size); i += a.size } else i++
        }
        return o
    }
}
