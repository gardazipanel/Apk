package com.h2a.runner

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.*
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.ByteArrayInputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var cfg = JSONObject()
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var pendingWebPermission: PermissionRequest? = null
    private var pendingWebResources: Array<String> = emptyArray()
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null

    private companion object {
        const val REQUEST_WEB_PERMISSION = 101
        const val REQUEST_LOCATION_PERMISSION = 102
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cfg = try {
            JSONObject(assets.open("config.json").bufferedReader().use { it.readText() })
        } catch (e: Exception) { JSONObject() }
        if (cfg.optBoolean("landscape")) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        try { window.statusBarColor = Color.parseColor(cfg.optString("color", "#0F9688")) } catch (e: Exception) {}
        if (cfg.optBoolean("fullscreen")) hideBars()

        val internet = cfg.optBoolean("internet", true)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        val splash = android.widget.ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            setBackgroundColor(Color.WHITE)
            scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
            val pad = (96 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }
        val frame = android.widget.FrameLayout(this)
        frame.addView(web, android.widget.FrameLayout.LayoutParams(-1, -1))
        frame.addView(splash, android.widget.FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            setGeolocationEnabled(cfg.optBoolean("location"))
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                splash.animate().alpha(0f).setDuration(300).withEndAction { splash.visibility = View.GONE }.start()
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                val res = loader.shouldInterceptRequest(u)
                if (res != null) return res
                if (!internet && (u.scheme == "http" || u.scheme == "https")) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) {
                runOnUiThread {
                    // Only ask Android when the website actually requests camera/microphone.
                    // Android remembers grants; reopening the app won't prompt again unless revoked.
                    if (pendingWebPermission != null) {
                        r.deny()
                        return@runOnUiThread
                    }
                    val allowed = r.resources.filter {
                        (it == PermissionRequest.RESOURCE_VIDEO_CAPTURE && cfg.optBoolean("camera")) ||
                            (it == PermissionRequest.RESOURCE_AUDIO_CAPTURE && cfg.optBoolean("mic"))
                    }
                    if (allowed.isEmpty()) {
                        r.deny()
                        return@runOnUiThread
                    }
                    val androidPerms = ArrayList<String>()
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in allowed &&
                        checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        androidPerms.add(Manifest.permission.CAMERA)
                    }
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in allowed &&
                        checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        androidPerms.add(Manifest.permission.RECORD_AUDIO)
                    }
                    if (androidPerms.isEmpty()) {
                        r.grant(allowed.toTypedArray())
                    } else {
                        pendingWebPermission = r
                        pendingWebResources = allowed.toTypedArray()
                        requestPermissions(androidPerms.toTypedArray(), REQUEST_WEB_PERMISSION)
                    }
                }
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String, cb: GeolocationPermissions.Callback) {
                runOnUiThread {
                    if (!cfg.optBoolean("location")) {
                        cb.invoke(origin, false, false)
                    } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        cb.invoke(origin, true, false)
                    } else {
                        pendingGeoOrigin = origin
                        pendingGeoCallback = cb
                        requestPermissions(
                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                            REQUEST_LOCATION_PERMISSION
                        )
                    }
                }
            }
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                if (!cfg.optBoolean("gallery") || p == null) { cb?.onReceiveValue(null); chooser = null; return true }
                return try { startActivityForResult(p.createIntent(), 77); true }
                catch (e: Exception) { chooser = null; cb?.onReceiveValue(null); true }
            }
            override fun onJsAlert(v: WebView?, url: String?, m: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setOnCancelListener { r.cancel() }.show()
                return true
            }
            override fun onJsConfirm(v: WebView?, url: String?, m: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show()
                return true
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_WEB_PERMISSION -> {
                val request = pendingWebPermission
                val resources = pendingWebResources
                pendingWebPermission = null
                pendingWebResources = emptyArray()
                if (request == null) return
                val grantedCamera = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                val grantedMic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                val resourcesToGrant = resources.filter {
                    (it == PermissionRequest.RESOURCE_VIDEO_CAPTURE && cfg.optBoolean("camera") && grantedCamera) ||
                        (it == PermissionRequest.RESOURCE_AUDIO_CAPTURE && cfg.optBoolean("mic") && grantedMic)
                }
                if (resourcesToGrant.isEmpty()) request.deny() else request.grant(resourcesToGrant.toTypedArray())
            }
            REQUEST_LOCATION_PERMISSION -> {
                val origin = pendingGeoOrigin
                val callback = pendingGeoCallback
                pendingGeoOrigin = null
                pendingGeoCallback = null
                if (origin != null && callback != null) {
                    val granted = cfg.optBoolean("location") &&
                        (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                    callback.invoke(origin, granted, false)
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && cfg.optBoolean("fullscreen")) hideBars()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        if (rc == 77) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            chooser = null
        } else super.onActivityResult(rc, res, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
