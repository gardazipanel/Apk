# HTML-to-APK Maker

Android Studio / Gradle project that packages a local HTML file or a ZIP website into an installable Android WebView APK.

## Features
- Select a single `.html` / `.htm` file or a ZIP containing `index.html`.
- Set app name, theme color, optional icon, and common capabilities.
- Build and sign the generated APK inside the Android app.
- Manage generated APKs, install them, or save a copy.
- Runtime permission requests are deferred until a website actually requests camera, microphone, or geolocation access.

## Permission behavior
- Camera and microphone: the generated app asks Android only when the web page invokes a WebView media permission request, and only for capabilities enabled in the builder and declared in the generated app.
- Location: the Android permission is requested only when the website asks for geolocation.
- Existing Android grants are checked before requesting permission, so launching the app again does not trigger a new prompt when permission remains granted.
- Users can revoke permissions in Android Settings. Android may prompt again after revocation, reinstall, reset, or if the user previously denied a permission.
- Gallery/file upload uses Android's system file picker, so broad storage access is not needed.
- This does not bypass Android's consent or permission rules.

## Build with GitHub Actions
1. Upload the contents of this project directory to a GitHub repository (the `.github/workflows/build.yml` file must be at the repository root).
2. Push to the `main` branch, or open **Actions → Build HTML-to-APK Maker → Run workflow**.
3. Download the `HTML-to-APK-Maker` artifact from the completed workflow run.
4. Install the debug APK on your Android device. Android may ask you to allow installation from the browser or file manager you use to install it.

The workflow generates a temporary development signing key for each build. This is suitable for testing. For a public production app, keep a private release keystore securely and reuse it for all updates.

## Local build
Requires JDK 17, Android SDK / Android Gradle Plugin dependencies, and Gradle 8.7.
The workflow creates `app/src/main/assets/sign.p12` and `app/src/main/assets/template.apk` before building the builder app. Those generated files are intentionally not committed.

```bash
keytool -J-Dkeystore.pkcs12.legacy -genkeypair \
  -keystore app/src/main/assets/sign.p12 \
  -storetype PKCS12 -storepass android -keypass android \
  -alias h2a -keyalg RSA -keysize 2048 -validity 36500 \
  -dname "CN=HTML to APK"

gradle :runner:assembleRelease --no-daemon
cp runner/build/outputs/apk/release/runner-release-unsigned.apk app/src/main/assets/template.apk
gradle :app:assembleDebug --no-daemon
```

## Important limitation
This wraps a website in Android WebView; it is not a general-purpose compiler for every website or arbitrary backend. External services, advanced browser APIs, server-side code, and sites requiring native SDKs may need extra implementation.
