package com.h2a.runner

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.*
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.ByteArrayInputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var cfg = JSONObject()
    private var chooser: ValueCallback<Array<Uri>>? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cfg = try {
            JSONObject(assets.open("config.json").bufferedReader().use { it.readText() })
        } catch (e: Exception) { JSONObject() }
        if (cfg.optBoolean("landscape")) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        try { window.statusBarColor = Color.parseColor(cfg.optString("color", "#0F9688")) } catch (e: Exception) {}
        if (cfg.optBoolean("fullscreen")) hideBars()
        askPermissions()

        val internet = cfg.optBoolean("internet", true)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            setGeolocationEnabled(cfg.optBoolean("location"))
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                val res = loader.shouldInterceptRequest(u)
                if (res != null) return res
                if (!internet && (u.scheme == "http" || u.scheme == "https")) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) {
                val ok = r.resources.filter {
                    (it == PermissionRequest.RESOURCE_VIDEO_CAPTURE && cfg.optBoolean("camera")) ||
                        (it == PermissionRequest.RESOURCE_AUDIO_CAPTURE && cfg.optBoolean("mic"))
                }
                runOnUiThread { if (ok.isEmpty()) r.deny() else r.grant(ok.toTypedArray()) }
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String, cb: GeolocationPermissions.Callback) {
                cb.invoke(origin, cfg.optBoolean("location"), false)
            }
            override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                if (!cfg.optBoolean("gallery") || p == null) { cb?.onReceiveValue(null); chooser = null; return true }
                return try { startActivityForResult(p.createIntent(), 77); true }
                catch (e: Exception) { chooser = null; cb?.onReceiveValue(null); true }
            }
            override fun onJsAlert(v: WebView?, url: String?, m: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setOnCancelListener { r.cancel() }.show()
                return true
            }
            override fun onJsConfirm(v: WebView?, url: String?, m: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show()
                return true
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    private fun askPermissions() {
        val need = ArrayList<String>()
        if (cfg.optBoolean("camera")) need.add(Manifest.permission.CAMERA)
        if (cfg.optBoolean("mic")) need.add(Manifest.permission.RECORD_AUDIO)
        if (cfg.optBoolean("location")) need.add(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && cfg.optBoolean("fullscreen")) hideBars()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        if (rc == 77) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            chooser = null
        } else super.onActivityResult(rc, res, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
